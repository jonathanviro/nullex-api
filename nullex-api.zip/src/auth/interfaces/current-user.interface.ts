export interface CurrentUserPayload {
  id: string;
  roleId: string;
}
