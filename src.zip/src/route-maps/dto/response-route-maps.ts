export class ResponseRouteMapDto {
  id: string;
  description: string;
  imgRoute1?: string;
  imgRoute2?: string;
  imgRoute3?: string;
  imgRoute4?: string;
  createdAt: Date;
  updatedAt: Date;
}
